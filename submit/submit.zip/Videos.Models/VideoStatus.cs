﻿namespace Videos.Models
{
    public enum VideoStatus
    {
        Published,
        Pending,
        Deleted
    }
}